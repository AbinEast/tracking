import 'package:google_maps_flutter/google_maps_flutter.dart';

enum EventType {
  geofenceIn,
  geofenceOut,
  overspeed,
  idle,
  offline,
  tamper,
}

class VehicleData {
  final String id;
  final LatLng position;
  final double speed; // in km/h
  final double heading;
  final DateTime timestamp;
  final bool isIgnitionOn;
  final int batteryLevel;

  VehicleData({
    required this.id,
    required this.position,
    required this.speed,
    required this.heading,
    required this.timestamp,
    required this.isIgnitionOn,
    required this.batteryLevel,
  });
}

class TrackingEvent {
  final String assetId;
  final DateTime timestamp;
  final EventType type;
  final LatLng location;
  final Map<String, dynamic> details;

  TrackingEvent({
    required this.assetId,
    required this.timestamp,
    required this.type,
    required this.location,
    required this.details,
  });

  @override
  String toString() {
    return 'Event: ${type.name}, Time: $timestamp, Loc: $location, Details: $details';
  }
}
