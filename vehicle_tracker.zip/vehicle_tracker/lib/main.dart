import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:battery_plus/battery_plus.dart';
import 'models.dart';
import 'event_processor.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Vehicle Tracker System',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const VehicleTrackerPage(),
    );
  }
}

class VehicleTrackerPage extends StatefulWidget {
  const VehicleTrackerPage({super.key});

  @override
  State<VehicleTrackerPage> createState() => _VehicleTrackerPageState();
}

class _VehicleTrackerPageState extends State<VehicleTrackerPage> {
  final Completer<GoogleMapController> _controller = Completer<GoogleMapController>();
  final EventProcessor _eventProcessor = EventProcessor();
  final Battery _battery = Battery();
  
  // Default location (Tugu Jogja)
  static const LatLng _center = LatLng(-7.782928, 110.367067);
  static const CameraPosition _kDefaultPosition = CameraPosition(
    target: _center,
    zoom: 14.4746,
  );

  Set<Marker> _markers = {};
  final Set<Circle> _circles = {};
  Set<Polyline> _polylines = {};
  final List<LatLng> _routePoints = [];
  
  StreamSubscription<Position>? _positionStreamSubscription;
  StreamSubscription<TrackingEvent>? _eventSubscription;
  
  VehicleData? _currentData;
  final List<TrackingEvent> _events = [];
  
  bool _isIgnitionOn = true; // Simulated ignition
  
  @override
  void initState() {
    super.initState();
    _setupGeofence();
    _setupEventListening();
    _checkPermissionsAndStartTracking();
  }

  void _setupGeofence() {
    _circles.add(Circle(
      circleId: const CircleId('geofence_tugu'),
      center: _eventProcessor.geofenceCenter,
      radius: _eventProcessor.geofenceRadius,
      fillColor: const Color.fromRGBO(244, 67, 54, 0.2), // Colors.red with opacity 0.2
      strokeColor: Colors.red,
      strokeWidth: 2,
    ));
  }

  void _setupEventListening() {
    _eventSubscription = _eventProcessor.eventStream.listen((event) {
      if (!mounted) return;
      setState(() {
        _events.insert(0, event); // Add to top of list
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('EVENT: ${event.type.name.toUpperCase()}'),
          backgroundColor: Colors.redAccent,
          duration: const Duration(seconds: 3),
        ),
      );
    });
  }

  Future<void> _simulateRoute() async {
    // Route: Tugu -> South (Mangkubumi) -> Fast -> Slow
    final List<Map<String, dynamic>> route = [
      {'lat': -7.782928, 'lng': 110.367067, 'speed': 20.0}, // Start Tugu
      {'lat': -7.783500, 'lng': 110.367067, 'speed': 40.0},
      {'lat': -7.784500, 'lng': 110.367067, 'speed': 60.0},
      {'lat': -7.785500, 'lng': 110.367067, 'speed': 90.0}, // Overspeed!
      {'lat': -7.786500, 'lng': 110.367067, 'speed': 95.0}, // Overspeed!
      {'lat': -7.787500, 'lng': 110.367067, 'speed': 40.0}, // Slow down
      {'lat': -7.788500, 'lng': 110.367067, 'speed': 0.0},  // Stop (Idle)
    ];

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Starting Route Simulation...')),
    );

    for (var point in route) {
      if (!mounted) break;
      
      _processPositionUpdate(Position(
        latitude: point['lat'],
        longitude: point['lng'],
        timestamp: DateTime.now(),
        accuracy: 5,
        altitude: 0,
        heading: 180, // South
        speed: (point['speed'] as double) / 3.6, // convert km/h back to m/s for Position object
        speedAccuracy: 0, 
        altitudeAccuracy: 0, 
        headingAccuracy: 0,
        isMocked: true,
      ));

      // Wait to simulate travel time
      await Future.delayed(const Duration(seconds: 2));
    }

    if (mounted) {
       ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Simulation Completed')),
      );
    }
  }

  Future<void> _checkPermissionsAndStartTracking() async {
    final status = await Permission.location.request();
    if (status.isGranted) {
      _startTracking();
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Location permission is required.')),
        );
      }
    }
  }

  void _startTracking() {
    const LocationSettings locationSettings = LocationSettings(
      accuracy: LocationAccuracy.high,
      distanceFilter: 5, 
    );

    _positionStreamSubscription = Geolocator.getPositionStream(locationSettings: locationSettings)
        .listen((Position position) {
      _processPositionUpdate(position);
    });
  }

  Future<void> _processPositionUpdate(Position position) async {
    int batteryLevel = await _battery.batteryLevel;
    
    // Create VehicleData object
    final data = VehicleData(
      id: 'vehicle_001',
      position: LatLng(position.latitude, position.longitude),
      speed: (position.speed * 3.6), // convert m/s to km/h
      heading: position.heading,
      timestamp: DateTime.now(),
      isIgnitionOn: _isIgnitionOn,
      batteryLevel: batteryLevel,
    );

    _eventProcessor.processData(data);
    _updateUI(data);
  }

  void _updateUI(VehicleData data) async {
    if (!mounted) return;
    
    setState(() {
      _currentData = data;
      _routePoints.add(data.position);
      
      _markers = {
        Marker(
          markerId: const MarkerId('vehicle'),
          position: data.position,
          rotation: data.heading,
          infoWindow: InfoWindow(
            title: 'Vehicle 001',
            snippet: '${data.speed.toStringAsFixed(1)} km/h',
          ),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
        ),
      };

      _polylines = {
        Polyline(
          polylineId: const PolylineId('route'),
          points: _routePoints,
          color: Colors.blue,
          width: 5,
        ),
      };
    });

    final GoogleMapController controller = await _controller.future;
    controller.animateCamera(CameraUpdate.newLatLng(data.position));
  }

  @override
  void dispose() {
    _positionStreamSubscription?.cancel();
    _eventSubscription?.cancel();
    _eventProcessor.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Vehicle Tracker System'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        actions: [
          IconButton(
            icon: const Icon(Icons.directions_car),
            tooltip: 'Simulate Drive Route',
            onPressed: _simulateRoute,
          ),
          IconButton(
            icon: Icon(_isIgnitionOn ? Icons.power : Icons.power_off),
            color: _isIgnitionOn ? Colors.green : Colors.red,
            tooltip: 'Toggle Ignition',
            onPressed: () {
              setState(() {
                _isIgnitionOn = !_isIgnitionOn;
              });
            },
          )
        ],
      ),
      body: Stack(
        children: [
          GoogleMap(
            mapType: MapType.normal,
            initialCameraPosition: _kDefaultPosition,
            onMapCreated: (GoogleMapController controller) {
              _controller.complete(controller);
            },
            onTap: (LatLng latLng) {
              // Simulation Mode: Teleport vehicle to tapped location
              _processPositionUpdate(Position(
                latitude: latLng.latitude,
                longitude: latLng.longitude,
                timestamp: DateTime.now(),
                accuracy: 0,
                altitude: 0,
                heading: 0,
                speed: 40, // Simulate moving speed
                speedAccuracy: 0, 
                altitudeAccuracy: 0, 
                headingAccuracy: 0,
                isMocked: true,
              ));
              
              ScaffoldMessenger.of(context).hideCurrentSnackBar();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Simulation: Teleported to tapped location'),
                  duration: Duration(seconds: 1),
                ),
              );
            },
            markers: _markers,
            circles: _circles,
            polylines: _polylines,
            myLocationEnabled: true,
            myLocationButtonEnabled: false,
          ),
          _buildDashboard(),
          _buildEventLog(),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          if (_currentData != null) {
             final GoogleMapController controller = await _controller.future;
             controller.animateCamera(CameraUpdate.newCameraPosition(
               CameraPosition(
                 target: _currentData!.position,
                 zoom: 17,
               ),
             ));
          }
        },
        child: const Icon(Icons.my_location),
      ),
    );
  }

  Widget _buildDashboard() {
    return Positioned(
      top: 10,
      left: 10,
      right: 10,
      child: Card(
        color: const Color.fromRGBO(255, 255, 255, 0.9), // White with opacity 0.9
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _buildInfoItem(
                    'Speed', 
                    '${_currentData?.speed.toStringAsFixed(1) ?? 0} km/h', 
                    Icons.speed,
                    _currentData != null && _currentData!.speed > 80 ? Colors.red : Colors.black,
                  ),
                  _buildInfoItem(
                    'Heading', 
                    '${_currentData?.heading.toStringAsFixed(0) ?? 0}°', 
                    Icons.explore
                  ),
                  _buildInfoItem(
                    'Engine', 
                    _isIgnitionOn ? 'ON' : 'OFF', 
                    Icons.settings_power,
                    _isIgnitionOn ? Colors.green : Colors.grey,
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                'Loc: ${_currentData?.position.latitude.toStringAsFixed(5) ?? 0}, ${_currentData?.position.longitude.toStringAsFixed(5) ?? 0}',
                style: const TextStyle(fontSize: 12, color: Colors.grey),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoItem(String label, String value, IconData icon, [Color color = Colors.black]) {
    return Column(
      children: [
        Icon(icon, color: color),
        const SizedBox(height: 4),
        Text(label, style: const TextStyle(fontSize: 10, color: Colors.grey)),
        Text(value, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: color)),
      ],
    );
  }

  Widget _buildEventLog() {
    return DraggableScrollableSheet(
      initialChildSize: 0.2,
      minChildSize: 0.1,
      maxChildSize: 0.5,
      builder: (context, scrollController) {
        return Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
            boxShadow: [BoxShadow(blurRadius: 10, color: Colors.black26)],
          ),
          child: Column(
            children: [
              Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.symmetric(vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const Padding(
                padding: EdgeInsets.only(bottom: 8.0),
                child: Text('Event Logs', style: TextStyle(fontWeight: FontWeight.bold)),
              ),
              Expanded(
                child: ListView.builder(
                  controller: scrollController,
                  itemCount: _events.length,
                  itemBuilder: (context, index) {
                    final event = _events[index];
                    return ListTile(
                      leading: Icon(_getEventIcon(event.type), color: Colors.red),
                      title: Text(event.type.name.toUpperCase()),
                      subtitle: Text('${event.timestamp.toString().split('.')[0]}\n${event.details}'),
                      isThreeLine: true,
                      dense: true,
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  IconData _getEventIcon(EventType type) {
    switch (type) {
      case EventType.overspeed: return Icons.speed;
      case EventType.geofenceIn: return Icons.login;
      case EventType.geofenceOut: return Icons.logout;
      case EventType.idle: return Icons.timer;
      case EventType.offline: return Icons.signal_wifi_off;
      case EventType.tamper: return Icons.warning;
    }
  }
}
